// $Id: Log_Msg_Backend.cpp 91286 2010-08-05 09:04:31Z johnnyw $

#include "ace/Log_Msg_Backend.h"




ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Log_Msg_Backend::~ACE_Log_Msg_Backend (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
