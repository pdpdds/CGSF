// $Id: Functor_String.cpp 91287 2010-08-05 10:30:49Z johnnyw $

#include "ace/Functor_String.h"

#if !defined (__ACE_INLINE__)
#include "ace/Functor_String.inl"
#endif /* __ACE_INLINE__ */


